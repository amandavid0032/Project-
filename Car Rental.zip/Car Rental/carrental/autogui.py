

import pyautogui
import emoji
import time                                                                                            
time.sleep(5)

count=0
while count<=50:
    pyautogui.typewrite("Thppd painge je gusse hoya")
    
    pyautogui.press("Enter") 
    count = count + 1
